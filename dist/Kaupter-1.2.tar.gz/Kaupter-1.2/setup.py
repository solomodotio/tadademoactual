from setuptools import setup

setup(
    name='Kaupter',
    description='Kaupter integration platform',
    version='1.2',
    url='https://github.com/dansolomo/kaupter_base',
    author='Dan Kauppi',
    author_email='dan@solomo.import',
    keywords=['integration','salesforce']
    )